<?php
session_start();

if (!isset($_SESSION['nombre'])) {
    header("Location: login.php");
    exit();
}

require_once("php/conexion.php");

$carrito = isset($_SESSION['carrito']) ? $_SESSION['carrito'] : [];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Carrito</title>
    <link rel="stylesheet" href="css/carrito.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
</head>
<body>

<a href="<?php echo isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'principal.php'; ?>" class="seguir-comprando">
    <i class="fa-solid fa-arrow-left"></i>
    Seguir comprando
</a>

<h1 class="titulo-carrito">Mi Carrito</h1>

<div class="carrito-container">

    <div class="carrito-productos">

        <?php

        $total = 0;

        if(!empty($carrito)){

            foreach($carrito as $index => $item){

                if(!is_array($item)) continue;

                $id = $item['id_producto'];

                $sql = "
                SELECT p.*, i.url_imagen
                FROM productos p
                LEFT JOIN imagenes_productos i
                ON p.id_producto = i.id_producto
                WHERE p.id_producto='$id'
                ";

                $resultado = $enlace->query($sql);
                $producto = $resultado->fetch_assoc();

                if(!$producto) continue;

                $total += $item['precio'];
        ?>

        <div class="producto-card">

            <div class="producto-info">

                <img
                src="assets/<?php echo $producto['url_imagen']; ?>"
                alt="Producto">

                <div>

                    <h3>
                        <?php echo $producto['nombre']; ?>
                    </h3>

                    <p>
                        Prenda de segunda mano
                    </p>

                </div>

            </div>

            <div class="producto-acciones">

                <span class="precio">
                    $<?php echo number_format($item['precio'],0,',','.'); ?>
                </span>

                <a href="php/eliminar_carrito.php?id=<?php echo $index; ?>"
                class="btn-eliminar">

                    Eliminar

                </a>

            </div>

        </div>

        <?php
            }

        }else{
        ?>

        <div class="carrito-vacio">

            <i class="fa-solid fa-cart-shopping"></i>

            <h2>
                Tu carrito está vacío
            </h2>

            <p>
                Agrega productos para comenzar tu compra.
            </p>

        </div>

        <?php } ?>

    </div>

    <div class="resumen-compra">

        <h2>Resumen</h2>

        <div class="resumen-item">

            <span>Total</span>

            <strong>
                $<?php echo number_format($total,0,',','.'); ?>
            </strong>

        </div>

        <?php if(!empty($carrito)){ ?>

        <a href="checkout.php" class="btn-comprar">

            Comprar ahora

        </a>

        <?php } ?>

    </div>

</div>

</body>
</html>